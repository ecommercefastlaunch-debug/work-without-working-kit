WORK WITHOUT WORKING: 61 SALES AND MARKETING SKILLS FOR CLAUDE

HOW TO ADD THEM
1. Open the Claude app, click the Code tab.
2. Paste this: Install the skills from sales-and-marketing-skills.zip in my Downloads folder.
   Claude unzips it and copies each skill into your skills folder (~/.claude/skills).
4. Start a NEW Code session. Type / to see your skills.

Easier way, if you have internet and Git: paste the Kit 02 prompt from
https://github.com/ecommercefastlaunch-debug/work-without-working-kit

WHAT'S INSIDE

Offers & positioning (9)
  offer-builder: Market research, competitors and offer statements from what you sell
  offers: Makes your offer stronger: bonuses, guarantees, honest urgency, upsells
  hundred-million-offers: Hormozi's Grand Slam Offer: value equation, bonus stack, guarantee
  product-marketing: Who it's for, why you, what to say first
  obviously-awesome: Positioning: your real competitors, what makes you different, your best customers
  storybrand-messaging: A clear one-liner and brand message where the customer is the hero
  pricing: What to charge, packages and tiers, raising prices
  customer-research: Turns customer messages and reviews into what they really want
  competitors: Fair comparisons with competitors ("us vs them")

Sales (8)
  sales-objections: Word-for-word answers to "too expensive", "I'll think about it" and more
  sales-followup: Follow-ups after a quote or inquiry, and for customers who went quiet
  negotiation: Calm scripts for haggling and discount requests
  proposal-pricing: Proposals and quotes with three price options
  sales-enablement: Sales one-pagers, talk tracks and objection sheets
  prospecting: Who to target first and how to spot buyers
  cold-email: Cold outreach messages that get replies
  100m-leads: Hormozi's Core Four for getting leads: warm, content, cold, ads

Copy & writing (10)
  copywriting: Offers, landing pages, headlines, product pages
  copy-editing: Tightens and proofreads your text without rewriting it
  made-to-stick: Makes your message simple, memorable and believable
  storytelling: Gives scripts and posts a story that holds attention
  hook-killers: Fixes weak opening lines
  marketing-psychology: Honest persuasion: social proof, anchoring, framing
  influence-psychology: Cialdini's 7 principles of persuasion for copy and sales
  stop-slop: Keeps the writing from sounding like AI
  anti-ai-writing: A final check that strips AI-sounding writing
  dumbify: Keeps explanations and customer messages simple

Ads & images (5)
  breakthrough-ads: 10 ad scripts per request, each from a different angle
  ad-creative: Ad headlines and copy variations
  ads: Plans paid ads: channel, budget, and why results changed
  ab-testing: Plans A/B tests and reads whether a result is real
  image-generation: Makes and edits images with your ChatGPT account (via Codex)

Social & video (11)
  social: Posts, carousels and content calendars
  social-captions: Captions for Facebook, Instagram, TikTok with A/B versions
  content-strategy: What to post about so content brings customers
  content-brief: A brief for one post before anyone writes it
  content-repurposing: One piece of content into many posts
  video-scripts: Short video scripts, beat by beat, with hooks
  viral-hooks: Opening lines that stop the scroll
  viral-captions-and-ctas: Captions and calls to action that get saves and replies
  viral-instagram-reels: Reels that reach new people
  viral-tiktok-content: TikTok scripts and ideas shaped for the For You page
  viral-short-form-ideas: Lots of short video ideas when you're stuck

Email, chat & leads (5)
  emails: Welcome, follow-up and win-back email sequences
  sms: Text and WhatsApp promos, abandoned cart, win-back
  whatsapp-marketing: Chat selling: broadcasts, flows, conversations (works for Messenger and Viber too)
  lead-magnets: Free guides and checklists that get you contacts
  scorecard-marketing: Quiz funnels that find and sort leads

Reviews & word of mouth (8)
  testimonial-request: Asks happy customers for a testimonial or review
  review-response-writer: Replies to Google and Facebook reviews, good and bad
  referrals: Refer-a-friend and affiliate programs
  contagious: Word of mouth and shareable ideas (STEPPS)
  influencer-marketing: Working with creators and influencers
  community-marketing: Growing a customer community or group
  co-marketing: Joint promos with partner businesses
  local-seo-manager: Google Business Profile, Maps ranking, local listings

Plans & launches (5)
  one-page-marketing: A one-page marketing plan, from stranger to raving fan
  marketing-plan: A full marketing plan with priorities and budget
  marketing-ideas: Marketing ideas when you have little time or budget
  launch: Plans a product launch or promo
  events: Webinars, booths and events, and following up after

WHERE THEY COME FROM
Each skill folder keeps its own LICENSE. Third-party skills are MIT licensed and come from:
  OneWave-AI/claude-skills, TheCraigHewitt/skills, alirezarezvani/claude-skills, arnabbagxd/Brand-building-skills, artemnovitckii/content-skills, coreyhaines31/marketingskills, getagentseal/founder-playbook, hardikpandya/stop-slop, minhnv0807/ai-business-skills, mohitagw15856/pm-claude-skills, vyralcontent/content-skills, wondelai/skills
The Work Without Working kit adds: offer-builder, sales-objections, sales-followup, hook-killers, breakthrough-ads, image-generation, content-repurposing.
image-generation uses your own ChatGPT account through Codex (see its SKILL.md).
