WORK WITHOUT WORKING: 25 VIDEO SKILLS FOR CLAUDE

HOW TO ADD THEM
1. Open the Claude app, click the Code tab.
2. Paste this: Install the skills from video-skills.zip in my Downloads folder.
   Claude unzips it and copies each skill into your skills folder (~/.claude/skills).
3. Start a NEW Code session. Type / to see your skills.

They work in every folder. To edit a video of yourself talking, also install
Herk Edit Kit (section 07, A. Setup Kit in your workbook).

Easier way, if you have internet and Git: paste the Video Skills prompt from
https://github.com/ecommercefastlaunch-debug/work-without-working-kit

WHAT'S INSIDE

Transitions & effects (3)
  hyperframes-registry: About 450 ready-made transitions, titles, captions, overlays and charts
  motion-effects: 16 premium motion effects in your brand
  sound-effects: Adds music and sound effects, mixed to the right loudness

Video basics (3)
  hyperframes: Makes and edits videos from code (read first for any video)
  hyperframes-cli: Preview, check and render videos
  media-use: Finds or makes music, sound effects, voiceover and images for a video

Explainers & promos (6)
  explainer-default: 45 to 90 second product demo
  explainer-engaging: 10 to 30 second one-take story explainer
  explainer-high-energy: 12 to 20 second hype promo
  launch-video: 30 to 45 second product launch video
  vox-explainer: 30 to 60 second documentary-style explainer
  apple-launch-film: Keynote-style launch film with Mac-style screens

B-roll & cutouts (2)
  motion-broll: Animated B-roll timed to what you say in a talking video
  object-separation: Cuts a person or product out of the background

Titles, charts & loops (5)
  title-sequence-3d: 8 to 15 second 3D title opener
  animated-chart: Looping chart: bars, counting numbers, before and after
  milestone-reveal: 12 second milestone or number reveal
  loop-cover: Looping GIF cover for a post or newsletter
  newsletter-promo: 12 to 20 second promo clip for a newsletter or blog

Reels & clips (2)
  reel-export: Turns any video into a 1080x1920 Reel or TikTok
  clip-factory: Finds the 8 to 12 best short clips in a long video

Plan & brief (4)
  brand-intake: Sets up your brand colors and motion rules first
  motion-brief-writer: Turns a rough idea into a clear brief for an animation
  motion-prompt-writer: Writes a complete prompt for one motion graphic
  reference-to-motion: Turns videos you admire into a plan for your own

Each skill comes from its original GitHub repo, with its license (MIT or Apache 2.0):
  github.com/Barty-Bart/motion-graphics
  github.com/charlie947/motion-graphics-skills
  github.com/heygen-com/hyperframes
  github.com/mohitagw15856/pm-claude-skills
